#include "ohos_init.h"


void HelloWorld(void)
{
    printf("[KP] Hello world !\r\n");
}

SYS_RUN(HelloWorld);
