#!/bin/bash
cp config/usr_config.mk ../../../soc/hisilicon/hi3861v100/sdk_liteos/build/config
cp config/sdk.mk ../../../soc/hisilicon/hi3861v100/sdk_liteos/build/config
cp config/app_io_init.c ../../../soc/hisilicon/hi3861v100/sdk_liteos/app/wifiiot_app/init/
cp config/app_main.c ../../../soc/hisilicon/hi3861v100/sdk_liteos/app/wifiiot_app/src

#cp app/40_KP_NFC_NAN/libs/libhilinkadapter_3861.a ../../../../out/qihang/qihang/libs
#cp app/40_KP_NFC_NAN/libs/libnetcfgdevicesdk.a ../../../../out/qihang/qihang/libs
#cp app/40_KP_NFC_NAN/libs/libHwKeystoreSDK.a ../../../../out/qihang/qihang/libs/libHwKeystoreSDK.a

