#ifndef __HEALTH_MODULE_H__
#define __HEALTH_MODULE_H__

#include <hi_types_base.h>
#include <hi_io.h>
#include <hi_early_debug.h>
#include <hi_gpio.h>
#include <hi_task.h>
#include <hi_i2c.h>
#include <hi_spi.h>
#include <hi_pwm.h>



#endif
