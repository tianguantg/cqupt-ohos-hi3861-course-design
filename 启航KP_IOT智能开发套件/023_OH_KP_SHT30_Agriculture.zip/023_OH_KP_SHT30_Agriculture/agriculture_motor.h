#ifndef __AGRICULTURE_MOTOR_H__
#define __AGRICULTURE_MOTOR_H__

typedef enum {
    MOTOR_SPEED_LEVEL_0 = 0, /* stop */
    MOTOR_SPEED_LEVEL_1,
    MOTOR_SPEED_LEVEL_2,
	MOTOR_SPEED_LEVEL_3,
	MOTOR_SPEED_LEVEL_MAX /* invalid */
} motor_speed_level;


/* 初始化舵机 */
void AgricultureMotorInit(void);

/* 舵机控制转动 */
void AgricultureMotorCtrl(motor_speed_level state);


#endif

