#ifndef __KP_PWM_H__
#define __KP_PWM_H__

#define PWM_DUTY_MIN 0
#define PWM_DUTY_MAX 100
#define PWM_SHORT_MAX 0xFFFF


unsigned int PwmInit(unsigned int clock, unsigned int port);

unsigned int PwmDeinit(unsigned int port);

unsigned int PwmStart(unsigned int port, unsigned int clock, unsigned short duty, unsigned int freq);

unsigned int PwmStop(unsigned int port);

#endif
