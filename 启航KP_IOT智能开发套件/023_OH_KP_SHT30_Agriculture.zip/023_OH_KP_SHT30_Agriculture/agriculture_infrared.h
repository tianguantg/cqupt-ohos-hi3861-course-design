#ifndef __HEALTH_LED_H__
#define __HEALTH_LED_H__

#include "kp_base_type.h"


/* 初始化INFRARED模块 */
void InfraredGpioInit(void);

/* 检测红外传感器并控制LED */
void InfraredCtrlTask(void);

/* ADC检测并控制LED */
static void AgricultureInfraredTask(void);


#endif

