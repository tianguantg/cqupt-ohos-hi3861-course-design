#include <stdio.h>
#include "ohos_init.h"
#include "cmsis_os2.h"
#include "hi_errno.h"
#include "iot_gpio.h"
#include "iot_gpio_ex.h"
#include "iot_adc.h"
#include "agriculture_led.h"

#define INFRARED_IO_GPIO_07  7
#define ADC_INFRARED_CHANNEL_3  3


/* 初始化INFRARED模块 */
void InfraredGpioInit(void)
{
    // 初始化LED引脚
    int ret = IoTGpioInit(INFRARED_IO_GPIO_07);
	if(ret != 0){ 
        printf("IoTGpioInit failed :%#x \r\n",ret);
		return;
    }

	/* 设置复用为GPIO功能 */
	ret = IoTGpioSetFunc(INFRARED_IO_GPIO_07, IOT_GPIO_FUNC_GPIO_7_GPIO);
	if(ret != 0){ 
        printf("IoTGpioSetFunc failed :%#x \r\n",ret);
		return;
    }

    /* 设置方向为输入 */
	ret = IoTGpioSetDir(INFRARED_IO_GPIO_07, IOT_GPIO_DIR_IN);
    if (ret != 0) {
        printf("IoTGpioSetDir failed :%#x \r\n",ret); 
        return;
    }
	
    printf("----- InfraredGpioInit success! -----\r\n");
}

/* 检测红外传感器并控制LED */
void InfraredCtrlTask(void)
{
    u32 ret = KP_ERR_SUCCESS;
	static led_state ledState = LED_OFF;

	while (1)
	{
    	/* 红外传感器引脚的默认值是低电平 */
    	IotGpioValue infraredValue = IOT_GPIO_VALUE0;
    	ret = IoTGpioGetInputVal(INFRARED_IO_GPIO_07, &infraredValue);
    	if (ret != KP_ERR_SUCCESS) {
            printf("IoTGpioGetInputVal failed :%#x \r\n", ret); 
            return;
        }
        if (infraredValue == IOT_GPIO_VALUE1) {
			if (ledState != LED_ON) {
        		AgricultureLedCtrl(LED_ON);
				ledState = LED_ON;
    			printf("Some objects approaching, alert led on \r\n");
			}
        } else {
            if (ledState != LED_OFF) {
                AgricultureLedCtrl(LED_OFF);
				ledState = LED_OFF;
				printf("Objects leave, alert led off \r\n");
            }
        }
		osDelay(300);
	}
}


/* ADC检测并控制LED */
static void AgricultureInfraredTask(void)
{
    unsigned short data = 0;
	unsigned int ret = HI_ERR_SUCCESS;
	
    /* 循环检测红外并处理 */
    while (1) {
	    /* 读取 ADC 信息 */
	    if ((ret = IoTAdcRead(ADC_INFRARED_CHANNEL_3, &data, IOT_ADC_EQU_MODEL_4, IOT_ADC_CUR_BAIS_DEFAULT, 0)) == HI_ERR_SUCCESS) {
	        printf("ADC_VALUE = %d \r\n", (unsigned int)data);

	        if(data > 150){
	            AgricultureLedCtrl(LED_ON);
	        }else{
	            AgricultureLedCtrl(LED_OFF);
	        }
	    } else {
			printf("IoTAdcRead failed :%#x \r\n", ret);
	    }
		osDelay(100);
    }

    return;
}

