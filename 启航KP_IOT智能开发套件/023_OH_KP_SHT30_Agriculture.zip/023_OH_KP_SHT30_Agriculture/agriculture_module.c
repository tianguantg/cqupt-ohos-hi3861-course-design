#include <stdio.h>
#include <unistd.h>
#include "ohos_init.h"
#include "cmsis_os2.h"
#include "iot_gpio.h"
#include "kp_base_type.h"
#include "agriculture_key.h"
#include "agriculture_infrared.h"
#include "agriculture_motor.h"

#define TASK_DELAY 200


/* 温湿度传感器处理任务，周期查询温度和湿度数据 */
void AgricultureShtTask(void)
{
    ShtIICInit();
	//osDelay(TASK_DELAY);
	SHT3X_init();
	osDelay(TASK_DELAY);
	
    /* 初始化变量 */
    float temperature = 0.0;
	float humidity = 0.0;
	static motor_speed_level motorSpeed = MOTOR_SPEED_LEVEL_0;
	
    while (1) {
		/* 查询温度和湿度数据 */
	    SHT3X_ReadMeasurementBuffer(&temperature, &humidity);
		//hi_watchdog_feed();
	    printf("temperature:%.2f, humidity:%.2f \r\n", temperature, humidity);
	    if (humidity > 80.0) {
			if (motorSpeed != MOTOR_SPEED_LEVEL_3) {
    			AgricultureMotorCtrl(MOTOR_SPEED_LEVEL_3);
				motorSpeed = MOTOR_SPEED_LEVEL_3;
    			printf("adjust motor speed to level 3 \r\n");
			}
	    } else if (humidity > 70.0) {
	        if (motorSpeed != MOTOR_SPEED_LEVEL_2) {
    			AgricultureMotorCtrl(MOTOR_SPEED_LEVEL_2);
				motorSpeed = MOTOR_SPEED_LEVEL_2;
    			printf("adjust motor speed to level 2 \r\n");
	        }
	    } else if (humidity > 60.0) {
			if (motorSpeed != MOTOR_SPEED_LEVEL_1) {
    			AgricultureMotorCtrl(MOTOR_SPEED_LEVEL_1);
				motorSpeed = MOTOR_SPEED_LEVEL_1;
    			printf("adjust motor speed to level 1 \r\n");
			}
	    } else {
	        if (motorSpeed != MOTOR_SPEED_LEVEL_0) {
    			AgricultureMotorCtrl(MOTOR_SPEED_LEVEL_0);
    			motorSpeed = MOTOR_SPEED_LEVEL_0;
    			printf("adjust motor speed to level 0 \r\n");
	        }
	    }
		osDelay(TASK_DELAY);
    }

    return;
}

void agriculture_sht30_demo(void)
{
    /* 各模块初始化 */
    //AgricultureKeyInit();
	AgricultureLedInit();
	AgricultureMotorInit();
	//ShtIICInit();
	//SHT3X_init();
	//osDelay(TASK_DELAY);

	/* 设置线程属性 */
    osThreadAttr_t attr;
    attr.name = "AgricultureKeyTask";
    attr.attr_bits = 0U;
    attr.cb_mem = NULL;
    attr.cb_size = 0U;
    attr.stack_mem = NULL;
    attr.stack_size = 1024 * 4;
    attr.priority = 20;

    /* 创建按键控制风扇线程 */
    osThreadId_t threadIDKey = osThreadNew((osThreadFunc_t)AgricultureKeyTask, NULL, &attr);
    if (threadIDKey == NULL)
    {
        printf("Falied to create AgricultureKeyTask!\r\n");
    }

    /* 创建红外传感器控制LED线程 */
	attr.name = "InfraredCtrlTask";
    osThreadId_t threadIDLed = osThreadNew((osThreadFunc_t)InfraredCtrlTask, NULL, &attr);
    if (threadIDKey == NULL)
    {
        printf("Falied to create InfraredCtrlTask!\r\n");
    }
	
    /* 创建温湿度处理线程 */
	attr.name = "AgricultureShtTask";
    osThreadId_t threadIDSht = osThreadNew((osThreadFunc_t)AgricultureShtTask, NULL, &attr);
    if (threadIDSht == NULL)
    {
        printf("Falied to create AgricultureShtTask!\r\n");
    }
}

APP_FEATURE_INIT(agriculture_sht30_demo);

