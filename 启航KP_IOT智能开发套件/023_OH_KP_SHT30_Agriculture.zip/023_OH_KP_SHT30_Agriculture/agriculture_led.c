#include "iot_gpio.h"
#include "iot_gpio_ex.h"
#include "agriculture_led.h"

#define LED_IO_GPIO_06  6


/* 初始化LED */
void AgricultureLedInit(void)
{
	/* LED报警灯连接芯片的GPIO6引脚，初始化GPIO-06引脚 */
    u8 ret = IoTGpioInit(LED_IO_GPIO_06);
	if(ret != KP_ERR_SUCCESS){ 
        printf("IoTGpioInit failed :%#x \r\n",ret);
		return;
    }

	/* 设置复用为GPIO功能 */
	ret = IoTGpioSetFunc(LED_IO_GPIO_06, IOT_GPIO_FUNC_GPIO_6_GPIO);
	if(ret != KP_ERR_SUCCESS){ 
        printf("IoTGpioSetFunc failed :%#x \r\n",ret);
		return;
    }

	/* 设置成输出有效，通过输出高电平点亮LED灯 */
	ret = IoTGpioSetDir(LED_IO_GPIO_06, IOT_GPIO_DIR_OUT);
	if(ret != KP_ERR_SUCCESS){ 
        printf("IoTGpioSetDir failed :%#x \r\n",ret);
		return;
    }
	
	printf("----- AgricultureLedInit success! -----\r\n");
}

/* 点亮或熄灭LED灯 */
void AgricultureLedCtrl(u32 state)
{
	switch (state){
		case LED_OFF:
		{
			IoTGpioSetOutputVal(LED_IO_GPIO_06, GPIO_OUT_LOW);
		    break;
		}
		case LED_ON:
    	{
			IoTGpioSetOutputVal(LED_IO_GPIO_06, GPIO_OUT_HIGH);
		    break;
		}
		case LED_SPARK:
		{
		    IoTGpioSetOutputVal(LED_IO_GPIO_06, GPIO_OUT_HIGH);
			osDelay(LED_SPARK_INTERVAL_TIME);
			IoTGpioSetOutputVal(LED_IO_GPIO_06, GPIO_OUT_LOW);
			osDelay(LED_SPARK_INTERVAL_TIME);
		    IoTGpioSetOutputVal(LED_IO_GPIO_06, GPIO_OUT_HIGH);
			osDelay(LED_SPARK_INTERVAL_TIME);
			IoTGpioSetOutputVal(LED_IO_GPIO_06, GPIO_OUT_LOW);
			break;
		}
		default:
		    printf("invalid LED state \r\n");
		    break;
    }
}

