#ifndef __HEALTH_LED_H__
#define __HEALTH_LED_H__

#include "kp_base_type.h"


//初始化烟雾探测模块的LED报警灯
void HealthLedInit(void);

//控制烟雾探测模块的LED报警灯，1:点亮; 2:熄灭
void HealthLedCtrl(u32 state);


#endif

