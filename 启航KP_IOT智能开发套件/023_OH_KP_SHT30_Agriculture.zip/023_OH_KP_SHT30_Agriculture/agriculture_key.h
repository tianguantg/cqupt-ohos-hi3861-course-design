#ifndef __AGRICULTURE_KEY_H__
#define __AGRICULTURE_KEY_H__

#include "kp_base_type.h"


void AgricultureKeyInit(void);
void AgricultureKeyTask(void);



#endif

